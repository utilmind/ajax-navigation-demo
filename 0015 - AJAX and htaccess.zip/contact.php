				<h3>CONTACT PAGE</h3>
				<p>
					The contact goes here and this gets loaded into the content-fill div if the contact link is clicked or someone visits www.sitename.com/contact.
				</p>