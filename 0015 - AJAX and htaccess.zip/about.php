				<h3>ABOUT PAGE</h3>
				<p>
					The about me goes here and this gets loaded into the content-fill div if the about link is clicked or someone visits www.sitename.com/about.
				</p>